<?php
/**
 * Dynamic XML Sitemap Generator
 * URL: https://adiari.shop/sitemap.xml
 * Helps Google index all pages including products, categories, and static pages
 */

// Load application bootstrap
define('APP_ROOT', dirname(__DIR__));

// Load config
if (file_exists(APP_ROOT . '/config/database.php')) {
    require_once APP_ROOT . '/config/database.php';
}
if (file_exists(APP_ROOT . '/app/core/Database.php')) {
    require_once APP_ROOT . '/app/core/Database.php';
}

header('Content-Type: application/xml; charset=utf-8');
header('X-Robots-Tag: noindex');

$baseUrl = 'https://adiari.shop';
$today = date('Y-m-d');

// Static pages
$staticPages = [
    ['loc' => '/',         'priority' => '1.0', 'changefreq' => 'daily'],
    ['loc' => '/products', 'priority' => '0.9', 'changefreq' => 'daily'],
    ['loc' => '/deals',    'priority' => '0.8', 'changefreq' => 'daily'],
    ['loc' => '/about',    'priority' => '0.5', 'changefreq' => 'monthly'],
    ['loc' => '/contact',  'priority' => '0.5', 'changefreq' => 'monthly'],
];

// Fetch products and categories from DB
$products = [];
$categories = [];

try {
    $db = Database::getInstance()->getConnection();

    // Get active products
    $stmt = $db->query("SELECT id, name, updated_at FROM products WHERE is_active = 1 ORDER BY updated_at DESC LIMIT 1000");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get active categories
    $stmt = $db->query("SELECT id, slug, name, updated_at FROM categories WHERE is_active = 1");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Silently continue - sitemap still generates with static pages
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

// Output static pages
foreach ($staticPages as $page) {
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($baseUrl . $page['loc']) . "</loc>\n";
    echo "    <lastmod>" . $today . "</lastmod>\n";
    echo "    <changefreq>" . $page['changefreq'] . "</changefreq>\n";
    echo "    <priority>" . $page['priority'] . "</priority>\n";
    echo "  </url>\n";
}

// Output category pages
foreach ($categories as $cat) {
    $lastmod = !empty($cat['updated_at']) ? date('Y-m-d', strtotime($cat['updated_at'])) : $today;
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($baseUrl . '/products?category=' . urlencode($cat['slug'])) . "</loc>\n";
    echo "    <lastmod>" . $lastmod . "</lastmod>\n";
    echo "    <changefreq>weekly</changefreq>\n";
    echo "    <priority>0.7</priority>\n";
    echo "  </url>\n";
}

// Output product pages
foreach ($products as $product) {
    $lastmod = !empty($product['updated_at']) ? date('Y-m-d', strtotime($product['updated_at'])) : $today;
    echo "  <url>\n";
    echo "    <loc>" . htmlspecialchars($baseUrl . '/products/' . $product['id']) . "</loc>\n";
    echo "    <lastmod>" . $lastmod . "</lastmod>\n";
    echo "    <changefreq>weekly</changefreq>\n";
    echo "    <priority>0.6</priority>\n";
    echo "  </url>\n";
}

echo '</urlset>';
